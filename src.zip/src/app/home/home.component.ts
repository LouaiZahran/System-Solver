import { Component } from '@angular/core';
@Component({
    selector: 'solve',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
  })
  export class homecomponent {
    externalnum:number=2
    delete(num:number)
    {
      
      var del =document.getElementById("0.5")
      del?.parentNode?.removeChild(del)
      this.externalnum=num
      this.set(num)
    }
    set(num:number)
    {
      var set2= document.createElement("div")
      set2.id="0.5"
      for(let i=0;i<num;i++)
      {
        var z=1
        var set= document.createElement("div")
        set.style.display="flex"
      
        for(let j=0;j<num;j++)
        { 
          var input =document.createElement("input") 
          input.style.width="50px"
          input.style.height="30px"
          input.style.marginTop="4px"
          input.style.marginLeft="5px"
          input.style.border="1px solid black"
          set.appendChild(input)
          var p=document.createElement("p")
          var text=document.createTextNode("x"+z)
          z=z+1
          p.style.marginLeft="8px"
          p.appendChild(text)
          set.appendChild(p)
          set2.appendChild(set)
          if(j!=num-1)
          { 
            var p2=document.createElement("p")
            var text2=document.createTextNode("+")
            p2.style.marginLeft="8px"
            p2.appendChild(text2)
            set.appendChild(p2)
            set2.appendChild(set)
            document.getElementById("0")?.appendChild(set2)
          }
         
        }
         
          var p3=document.createElement("p")
          var text3=document.createTextNode("=")
          p3.style.marginLeft="8px"
          p3.appendChild(text3)
          set.appendChild(p3)
          var input2 =document.createElement("input") 
          input2.style.width="50px"
          input2.style.height="30px"
          input2.style.marginTop="4px"
          input2.style.marginLeft="5px"
          input2.style.border="1px solid black"
          set.appendChild(input2) 
          set2.appendChild(set)
          document.getElementById("0")?.appendChild(set2)
      
      }
    
    }
    
  }